/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    uint16 Result0 = 0;
    uint16 value0;
    uint16 temp0;
    uint16 Result1 = 0;
    uint16 value1;
    uint16 temp1;
    
    ADC0_Start();
    ADC0_StartConvert();
    ADC1_Start();
    ADC1_StartConvert();
    LCD_Start();

    for(;;)
    {
        LCD_ClearDisplay();
        
        Result0 = 0;
        for(int i=0; i<=7; i++)
        {
            ADC0_IsEndConversion(ADC0_WAIT_FOR_RESULT);
            temp0 = ADC0_CountsTo_mVolts(ADC0_GetResult16());
            Result0 += temp0;
        } 
        value0 = Result0/8;
        
       // LCD_Position(0,0);
        //LCD_PrintNumber(value0);
       // CyDelay(250);
        
        Result1 = 0;
        for(int i=0; i<=7; i++)
        {
            ADC1_IsEndConversion(ADC1_WAIT_FOR_RESULT);
            temp1 = ADC1_CountsTo_mVolts(ADC1_GetResult16());
            Result1 += temp1;
        } 
        value1 = Result1/8;
        //LCD_Position(0,0);
        //LCD_PrintNumber(value1);
        //CyDelay(250);
        
        
        LCD_Position(0,0);
        if(value0 < 2345) //left values
        {
            LCD_PrintString("Left");
        }
        else if(value0 > 2362) //right values
        {
            LCD_PrintString("Right");
        }
        else
        {
            LCD_PrintString("Stationary");
        }      
        
        
        
        LCD_Position(1,0);
        if(value1 > 2390) //forward values
        {
            LCD_PrintString("Forward");
        }
        else if(value1 < 2383) //backward values
        {
            LCD_PrintString("Backward");
        }
        else
        {
            LCD_PrintString("Stationary");
        }
        CyDelay(250); 
    }
}
/* [] END OF FILE */
